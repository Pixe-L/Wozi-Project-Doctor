<!DOCTYPE html>
<?=$headGNRL?>
<body>
<?=$header?>

<div class="uk-container" style="min-height: 80vh;">

</div>

<?=$footer?>

<?=$scriptGNRL?>

</body>
</html>