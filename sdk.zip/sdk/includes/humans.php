<?php
header("Content-type: text/plain; charset=utf-8");
echo '/* TEAM */
	Coordinadora de proyecto: Ana Paula Covarrubias
	Email: pau@wozial.com
	From: Guadalajara, Jalisco, Mexico

	Coordinador de programación: Efrain Gonzalez Macias
	Email: info@efra.biz
	Email: ing_efrain@yahoo.com
	Facebook: ing.efrain.glz
	Instagram: ing_efrain_glz
	Twitter: @ing_efrain
	Whatsapp: 
	From: Guadalajara, Jalisco, Mexico

	Diseño Gráfico: Claudia Magaña 
	Email: clau.grafico@gmail.com
	Whatsapp: 33 1456 6714
	From: Guadalajara, Jalisco, Mexico

	Diseño Gráfico: Abel Quintero Perez. 
	Email: abelqpdesign@gmail.com
	Whatsapp: 33 1108 15 08
	From: Guadalajara, Jalisco, Mexico

	Programación web: Pablo Antonio Leyva Muñoz
	Email: pablo.leyvam@gmail.com
	Whatsapp: 33 1462 0116
	From: , Jalisco, Mexico

	Programación web: Pablo Adrian Piedra Moreno
	Email: adriandunk.182@gmail.com
	Whatsapp: 33 3970 9621
	From: Tlaquepaque, Jalisco, Mexico

	Programación web: Pablo Antonio Leyva Muñoz
	Email: vero.c.urena@gmail.com
	Whatsapp: 33 3181 3983
	From: Guadalajara, Jalisco, Mexico

	Departamento Comercial: Alejandro Aguilera Portillo.
	Email:correo.de.aletz@gmail.com
	Whatsapp: 33 1073 8204
	From: Guadalajara, Jalisco, Mexico

	Departamento Redes: Susana Esmeralda Cornejo Murillo.
	Email:susana13cornejo@gmail.com
	Whatsapp: 33 1366 5573
	From: Guadalajara, Jalisco, Mexico
';